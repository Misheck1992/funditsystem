<?php


class Security extends  CI_Controller
{

}
